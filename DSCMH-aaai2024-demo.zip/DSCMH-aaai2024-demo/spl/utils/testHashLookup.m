function testHashLookup()
end