function [ImgToTxt,TxtToImg] = DSCMH_con(trainLabel, param, dataset)
seed = 2023;
% rng('default');
rng(seed);

X1 = dataset.XDatabase;
X2 = dataset.YDatabase;
XTest = dataset.XTest;
YTest = dataset.YTest;
testL = dataset.testL;
databaseL = dataset.databaseL;
databaseL= NormalizeFea(databaseL,1);
% top_K=1000;
[d1,~] = size(X1');
[d2,~] = size(X2');
bit = param.bit;
maxIter = param.maxIter;
lambda = param.lambda;
alpha = param.alpha;

numTrain = size(trainLabel, 1);
cmm=16;
gamma1_SPLs=8;
gamma1_SPLb=2;
pace=1.2;
%--------------------------------initial------------------------------------

B= ones(bit, numTrain);
B(randn(bit, numTrain) < 0) = -1;
V1 = randn(bit, numTrain);
LOSS1 = zeros(size(X1'));
L1_SPLs = zeros(size(LOSS1,2),1);
R1_SPLs = ones(size(LOSS1,2),1);
L1_SPLb = zeros(size(LOSS1,1),1);
R1_SPLb = ones(size(LOSS1,1),1);

SPL1_s=[];
SPL1_b=[];

tic
for epoch = 1:maxIter
    % Ut-Step
      SPLsXT1=bsxfun(@times,R1_SPLs,V1');  
      U1=(X1'*SPLsXT1)*pinv(V1*SPLsXT1);
      U2=(X2'*SPLsXT1)*pinv(V1*SPLsXT1);
      
    % Vt-Step
    SPLsXB1=bsxfun(@times,R1_SPLs,X1); 
    SPLbXU1=bsxfun(@times,R1_SPLb,U1); 
    SPLsXB2=bsxfun(@times,R1_SPLs,X2); 
    SPLbXU2=bsxfun(@times,R1_SPLb,U2); 
    ZV1 = (SPLsXB1*SPLbXU1+SPLsXB2*SPLbXU2) + bit * databaseL * (databaseL' *  alpha*B');
    V1 = myOrth(ZV1)';

    % B-Step
    B = sign(bit*(alpha*V1)*databaseL*databaseL');   
 
    % rs^t-Step
    LOSS1_s = zeros(size(X1'));
    LOSS1_s = LOSS1_s+bsxfun(@times,R1_SPLb,X1'-U1*V1);
    for ind = 1:size(LOSS1_s,2)
        L1_SPLs(ind) = norm(LOSS1_s(:,ind),'fro');
    end
    L1_SPLs = L1_SPLs';
    L1_SPLs = mapminmax(L1_SPLs, 0, cmm);
    L1_SPLs= L1_SPLs';
%     gamma1_SPLs=median( L1_SPLs , 'all' );
    for ind = 1:size(L1_SPLs,1)
        me = (1+exp(-gamma1_SPLs));
        de = (1+exp(L1_SPLs(ind)-gamma1_SPLs));
        R1_SPLs(ind) = me/de;
    end
    gamma1_SPLs=pace*gamma1_SPLs;
        SPL1_s=[SPL1_s,R1_SPLs];


    % rb^t-Step
    LOSS1_b = zeros(size(X1'));
    LOSS1_b = LOSS1_b+bsxfun(@times,X1'-U1*V1,R1_SPLs');
    for ind = 1:size(LOSS1_b,1)
        L1_SPLb(ind) = norm(LOSS1_b(:,ind),'fro');
    end
    L1_SPLb = L1_SPLb';
    L1_SPLb = mapminmax(L1_SPLb, 0, cmm);
    L1_SPLb= L1_SPLb';
%     gamma1_SPLb=median( L1_SPLb , 'all' );
    for ind = 1:size(L1_SPLb,1)
        me = (1+exp(-gamma1_SPLb));
        de = (1+exp(L1_SPLb(ind)-gamma1_SPLb));
        R1_SPLb(ind) = me/de;
    end
        gamma1_SPLb=pace*gamma1_SPLb;
        SPL1_b=[SPL1_b,R1_SPLb];
 
 
end

    P1 = (X1' * X1 + lambda * eye(d1, d1)) \ (X1' * B');
    P1=P1';
    P2 = (X2' * X2 + lambda * eye(d2, d2)) \ (X2' * B');
    P2=P2';

%     P1 = pinv(B*B'+lambda*eye(bit))*(bit*B*databaseL*databaseL'*X1+lambda*B*X1)*pinv(X1'*X1);
%     P2 = pinv(B*B'+lambda*eye(bit))*(bit*B*databaseL*databaseL'*X2+lambda*B*X2)*pinv(X2'*X2);
   
    
    
% for epoch = 1:maxIter
%       % P-Step
%    
% %     fun(epoch)=norm(B-B_old,'fro')/norm(B_old,'fro');
% end

toc

%    %real-time evaluation
tBX = sign(P1*XTest');
tBY = sign(P2*YTest');
B(B<0) = 0;
B = compactbit(B');
tBX(tBX<0) = 0;
tBX = compactbit(tBX');
tBY(tBY<0) = 0;
tBY = compactbit(tBY');
Dhamm1 = hammingDist(tBY, B);
[~, HammingRank]=sort(Dhamm1,2);
out.MAP_test(1) = cal_mAP(databaseL,testL,HammingRank);
[out.Image_VS_Text_precision, out.Image_VS_Text_recall] = precision_recall(HammingRank',databaseL,testL);
% out.Image_To_Text_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
Dhamm2 = hammingDist(tBX, B);
[~, HammingRank]=sort(Dhamm2,2);
out.MAP_test(2) = cal_mAP(databaseL,testL,HammingRank);
[out.Text_VS_Image_precision, out.Text_VS_Image_recall] = precision_recall(HammingRank', databaseL,testL);
% out.Text_To_Image_Precision = precision_at_k(HammingRank', databaseL,testL,top_K);
ImgToTxt=out.MAP_test(1);
TxtToImg=out.MAP_test(2);

% Image_VS_Text_precision=out.Image_VS_Text_precision;
% Image_VS_Text_recall=out.Image_VS_Text_recall;
% Image_To_Text_Precision=out.Image_To_Text_Precision;
% Text_VS_Image_precision=out.Text_VS_Image_precision;
% Text_VS_Image_recall=out.Text_VS_Image_recall;
% Text_To_Image_Precision=out.Text_To_Image_Precision;

% save('HCCH_result_flickr_cur.mat','Image_VS_Text_precision','Image_VS_Text_recall','Text_VS_Image_precision','Text_VS_Image_recall');


end